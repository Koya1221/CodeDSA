package org.example;

public class StudentManagement {
    StudentStack studentStack;
    public  StudentManagement(){
        studentStack = new StudentStack();
    }
    public void addStudent(Student student)
    {
    }

}
